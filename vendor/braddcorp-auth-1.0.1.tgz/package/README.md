# @braddcorp/auth

Shared **custom Clerk auth UI** for BraddCorp Next.js sites. One package —
update the kit, then every consumer picks it up with `npm update @braddcorp/auth`
(or Renovate). No more re-copying forms site-by-site.

Built on **Clerk Core 3** (`@clerk/nextjs` v7+). No Clerk `<SignIn>` /
`<SignUp>` / `<UserButton>` chrome.

## Install

```bash
npm install github:BadBraddA1/braddcorp-auth#v1.0.0
# or track main (always latest commit after update):
# npm install github:BadBraddA1/braddcorp-auth#main
```

In `next.config`:

```js
transpilePackages: ["@braddcorp/auth"],
```

## Wire-up (per site)

1. Keep a local `lib/auth-config.ts` (`satisfies AuthConfig` — see
   `templates/nextjs/lib/auth-config.ts`).
2. Import styles in `app/layout.tsx`:

```ts
import "@braddcorp/auth/styles.css"
import "@/styles/auth-tokens.css" // site :root brand tokens only
```

3. Wrap the tree (inside `ClerkProvider`) with config:

```tsx
import { AuthKitProvider } from "@braddcorp/auth"
import { authConfig } from "@/lib/auth-config"

<ClerkProvider>
  <AuthKitProvider config={authConfig}>{children}</AuthKitProvider>
</ClerkProvider>
```

4. Auth pages import from the package:

```tsx
import {
  AuthShell,
  SignInForm,
  safeReturnPath,
} from "@braddcorp/auth"
```

5. Copy route stubs from `templates/nextjs/app/*` if the site is new.
   Edit only `auth-config.ts` + `auth-tokens.css` for brand.

Optional gates (Turnstile, etc.) use form props: `beforeEmailContinue`,
`emailStepExtra`, `beforeSubmit`, `formExtra`, `beforeSendCode`.

## Updating all sites after a kit change

1. Bump / tag in this repo (`v1.0.1`, …) and push.
2. In each consumer:

```bash
npm install github:BadBraddA1/braddcorp-auth#v1.0.1
# or, if on #main:
npm update @braddcorp/auth
```

3. Commit the lockfile. Deploy.

For “always latest main”, pin `#main` and run `npm update @braddcorp/auth`
(or Renovate on the github dependency) across repos after kit pushes.

## What’s still site-local

| File | Why |
| --- | --- |
| `lib/auth-config.ts` | Site name, URLs, copy, social |
| `styles/auth-tokens.css` | Brand `:root` tokens |
| `app/sign-in` etc. | Thin pages / site extras |
| Turnstile wrappers | Site spam protection |

## Agent install

See [`SKILL.md`](SKILL.md).

## Legacy copy-in

`templates/nextjs/components/auth/*` is no longer the source of truth — the
package `src/` is. Templates keep pages, middleware, config stub, and token CSS.
