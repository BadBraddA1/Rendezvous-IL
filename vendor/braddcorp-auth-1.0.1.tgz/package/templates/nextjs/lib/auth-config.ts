/**
 * Per-site auth settings — keep this file in the site.
 * Forms/shell come from `@braddcorp/auth`; brand colors live in
 * `styles/auth-tokens.css`.
 */

import type { AuthConfig, SocialProvider } from "@braddcorp/auth"

export type { SocialProvider }

export const authConfig = {
  /** Shown in shell headers and page metadata. */
  siteName: "SITE NAME",

  /** Small link above the heading, back to the home page. */
  homeUrl: "/",

  /** Where finalize() sends users after auth. */
  afterSignInUrl: "/account",
  afterSignUpUrl: "/account",

  /** Route paths — keep in sync with the app/ folders and .env. */
  signInUrl: "/sign-in",
  signUpUrl: "/sign-up",
  forgotPasswordUrl: "/forgot-password",
  ssoCallbackUrl: "/sso-callback",

  /** Collect first/last name on sign-up (requires "Name" enabled in Clerk). */
  collectName: true,

  /**
   * Absolute redirect_url values on these hosts are honored after sign-in
   * (middleware deep-link returns). Relative paths are always allowed.
   */
  allowedReturnHosts: [] as string[],

  /** OAuth buttons to render. Empty array hides the social block. */
  socialProviders: [] as SocialProvider[],

  copy: {
    signInTitle: "Welcome back",
    signInSubtitle: "Sign in to your account.",
    signUpTitle: "Create your account",
    signUpSubtitle: "Sign up to get started.",
    forgotTitle: "Reset your password",
    forgotSubtitle: "We'll email you a reset code.",
  },
} satisfies AuthConfig
