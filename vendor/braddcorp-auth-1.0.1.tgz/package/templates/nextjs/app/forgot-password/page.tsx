import type { Metadata } from "next"
import { AuthShell, ForgotPasswordForm, safeReturnPath } from "@braddcorp/auth"
import { authConfig } from "@/lib/auth-config"

export const metadata: Metadata = {
  title: `Reset Password — ${authConfig.siteName}`,
  description: authConfig.copy.forgotSubtitle,
}

export default async function ForgotPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ redirect_url?: string; email?: string }>
}) {
  const { redirect_url, email } = await searchParams
  const afterUrl =
    safeReturnPath(redirect_url, authConfig.allowedReturnHosts) ??
    authConfig.afterSignInUrl

  return (
    <AuthShell
      title={authConfig.copy.forgotTitle}
      subtitle={authConfig.copy.forgotSubtitle}
      altPrompt="Remembered it?"
      altHref={authConfig.signInUrl}
      altLabel="Back to sign in"
    >
      <ForgotPasswordForm afterUrl={afterUrl} defaultEmail={email} />
    </AuthShell>
  )
}
