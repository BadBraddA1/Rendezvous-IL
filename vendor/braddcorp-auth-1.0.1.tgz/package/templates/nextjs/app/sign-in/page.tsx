import type { Metadata } from "next"
import { AuthShell, SignInForm, safeReturnPath } from "@braddcorp/auth"
import { authConfig } from "@/lib/auth-config"

export const metadata: Metadata = {
  title: `Sign In — ${authConfig.siteName}`,
  description: authConfig.copy.signInSubtitle,
}

export default async function SignInPage({
  searchParams,
}: {
  searchParams: Promise<{ redirect_url?: string }>
}) {
  const { redirect_url } = await searchParams
  const afterUrl =
    safeReturnPath(redirect_url, authConfig.allowedReturnHosts) ??
    authConfig.afterSignInUrl

  return (
    <AuthShell
      title={authConfig.copy.signInTitle}
      subtitle={authConfig.copy.signInSubtitle}
      altPrompt="New here?"
      altHref={authConfig.signUpUrl}
      altLabel="Create an account"
    >
      <SignInForm afterUrl={afterUrl} />
    </AuthShell>
  )
}
