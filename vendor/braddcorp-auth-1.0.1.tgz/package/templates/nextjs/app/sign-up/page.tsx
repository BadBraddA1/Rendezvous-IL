import type { Metadata } from "next"
import { AuthShell, SignUpForm } from "@braddcorp/auth"
import { authConfig } from "@/lib/auth-config"

export const metadata: Metadata = {
  title: `Sign Up — ${authConfig.siteName}`,
  description: authConfig.copy.signUpSubtitle,
}

export default async function SignUpPage({
  searchParams,
}: {
  searchParams: Promise<{ email?: string }>
}) {
  const { email } = await searchParams

  return (
    <AuthShell
      title={authConfig.copy.signUpTitle}
      subtitle={authConfig.copy.signUpSubtitle}
      altPrompt="Already have an account?"
      altHref={authConfig.signInUrl}
      altLabel="Sign in"
    >
      <SignUpForm prefillEmail={email} />
    </AuthShell>
  )
}
