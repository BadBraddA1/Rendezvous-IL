"use client"

import { useState } from "react"
import Link from "next/link"
import { useSignIn } from "@clerk/nextjs"
import { authConfig } from "@/lib/auth-config"
import { afterAuth, globalAuthError } from "@/lib/after-auth"
import { AuthPending } from "./auth-pending"
import { NewPasswordField } from "./password-requirements"

function hasStrategy(
  factors: { strategy: string }[] | null | undefined,
  strategy: string,
) {
  return Boolean(factors?.some((f) => f.strategy === strategy))
}

/**
 * Three-step password reset (Clerk Core 3 resetPasswordEmailCode API):
 * 1. email → send reset code
 * 2. verify code
 * 3. set new password → signed in
 *
 * If the account has no password yet (imported / admin-created), reset isn't
 * available — we fall back to email-code sign-in and tell the user why.
 */
export function ForgotPasswordForm({
  afterUrl = authConfig.afterSignInUrl,
  defaultEmail,
}: {
  /** Override for secondary flows (e.g. a client portal landing page). */
  afterUrl?: string
  /** Prefill for reset links that carry ?email= (e.g. admin-sent emails). */
  defaultEmail?: string
}) {
  const { signIn, errors, fetchStatus } = useSignIn()
  const [codeSent, setCodeSent] = useState(false)
  const [redirecting, setRedirecting] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)
  /** Passwordless account: using email-code sign-in instead of reset. */
  const [passwordlessSignIn, setPasswordlessSignIn] = useState(false)
  const busy = fetchStatus === "fetching"
  const globalErr = globalAuthError(errors)
  const bannerError =
    actionError || globalErr?.longMessage || globalErr?.message || null

  async function sendCode(formData: FormData) {
    setActionError(null)
    setPasswordlessSignIn(false)
    const identifier = formData.get("email") as string

    const { error: createError } = await signIn.create({ identifier })
    if (createError) return

    const canReset = hasStrategy(
      signIn.supportedFirstFactors,
      "reset_password_email_code",
    )
    const canEmailCode = hasStrategy(signIn.supportedFirstFactors, "email_code")

    if (canReset) {
      const { error } = await signIn.resetPasswordEmailCode.sendCode()
      if (error) return
      setCodeSent(true)
      return
    }

    // No password on this account — reset strategy isn't valid. Help them
    // sign in with an email code instead of showing Clerk's raw error.
    if (canEmailCode) {
      const { error } = await signIn.emailCode.sendCode()
      if (error) {
        setActionError(
          error.longMessage ??
            error.message ??
            "Could not email a sign-in code. Try again.",
        )
        return
      }
      setPasswordlessSignIn(true)
      setCodeSent(true)
      return
    }

    setActionError(
      "This account can't reset a password from here. Try signing in, or contact support.",
    )
  }

  async function verifyResetCode(formData: FormData) {
    setActionError(null)
    const code = formData.get("code") as string
    await signIn.resetPasswordEmailCode.verifyCode({ code })
  }

  async function verifySignInCode(formData: FormData) {
    setActionError(null)
    const code = formData.get("code") as string
    const { error } = await signIn.emailCode.verifyCode({ code })
    if (error) return

    if (signIn.status === "complete") {
      setRedirecting(true)
      await signIn.finalize({
        navigate: afterAuth(afterUrl),
      })
    }
  }

  async function submitNewPassword(formData: FormData) {
    setActionError(null)
    const password = formData.get("password") as string

    const { error } = await signIn.resetPasswordEmailCode.submitPassword({
      password,
      signOutOfOtherSessions: true,
    })
    if (error) return

    if (signIn.status === "complete") {
      setRedirecting(true)
      await signIn.finalize({
        navigate: afterAuth(afterUrl),
      })
    }
  }

  // Hold the spinner until the browser actually leaves the page.
  if (redirecting || signIn.status === "complete") {
    return (
      <AuthPending
        label={
          passwordlessSignIn
            ? "Signing you in…"
            : "Password saved — signing you in…"
        }
      />
    )
  }

  if (signIn.status === "needs_new_password") {
    return (
      <form action={submitNewPassword} className="ba-form">
        <NewPasswordField
          label="New password"
          invalid={Boolean(errors.fields.password)}
          errorMessage={errors.fields.password?.message}
        />
        {bannerError && <p className="ba-error">{bannerError}</p>}
        <button type="submit" className="ba-button" disabled={busy}>
          {busy ? "Saving…" : "Set new password"}
        </button>
      </form>
    )
  }

  if (codeSent) {
    return (
      <form
        action={passwordlessSignIn ? verifySignInCode : verifyResetCode}
        className="ba-form"
      >
        <p className="ba-hint">
          {passwordlessSignIn
            ? "This account doesn't have a password yet, so we emailed a sign-in code instead. After you're in, you can set a password from your account."
            : "Enter the reset code from your email."}
        </p>
        <div className="ba-field">
          <label htmlFor="code" className="ba-label">
            {passwordlessSignIn ? "Sign-in code" : "Reset code"}
          </label>
          <input
            id="code"
            name="code"
            type="text"
            inputMode="numeric"
            autoComplete="one-time-code"
            required
            className="ba-input"
            aria-invalid={Boolean(errors.fields.code)}
          />
          {errors.fields.code && (
            <p className="ba-error">{errors.fields.code.message}</p>
          )}
        </div>
        {bannerError && <p className="ba-error">{bannerError}</p>}
        <button type="submit" className="ba-button" disabled={busy}>
          {busy
            ? "Verifying…"
            : passwordlessSignIn
              ? "Sign in"
              : "Verify code"}
        </button>
        <button
          type="button"
          className="ba-link"
          onClick={() => {
            if (passwordlessSignIn) {
              void signIn.emailCode.sendCode()
            } else {
              void signIn.resetPasswordEmailCode.sendCode()
            }
          }}
        >
          Send a new code
        </button>
        <Link href={authConfig.signInUrl} className="ba-link">
          Back to sign in
        </Link>
      </form>
    )
  }

  return (
    <form action={sendCode} className="ba-form">
      <div className="ba-field">
        <label htmlFor="email" className="ba-label">
          Email address
        </label>
        <input
          id="email"
          name="email"
          type="email"
          autoComplete="email"
          required
          defaultValue={defaultEmail}
          className="ba-input"
          aria-invalid={Boolean(errors.fields.identifier)}
        />
        {errors.fields.identifier && (
          <p className="ba-error">{errors.fields.identifier.message}</p>
        )}
      </div>
      {bannerError && <p className="ba-error">{bannerError}</p>}
      <button type="submit" className="ba-button" disabled={busy}>
        {busy ? "Sending…" : "Send reset code"}
      </button>
    </form>
  )
}
