# BraddCorp Auth Kit — agent install guide (`@braddcorp/auth`)

Custom Clerk auth UI (no Clerk chrome) as a **shared npm package**. When the
user says "use the auth kit" / "hit braddcorp-auth", follow this file.

Built on **Clerk Core 3** (`@clerk/nextjs` v7+). Do NOT use Clerk Elements,
legacy `signIn.create()/setActive()`, or prebuilt `<SignIn>` / `<SignUp>` /
`<UserButton>` / `<UserProfile>`. Account chrome is `<AccountMenu />`.

## 0. Requirements

- Next.js App Router
- `@clerk/nextjs` **v7+**
- Clerk app with email + password sign-up/sign-in

## 1. Install the package

From the site repo:

```bash
npm install github:BadBraddA1/braddcorp-auth#v1.0.0
# tracking tip of main (optional):
# npm install github:BadBraddA1/braddcorp-auth#main
```

Add to Next config:

```js
transpilePackages: ["@braddcorp/auth"],
```

## 2. Site-local files (copy from `templates/nextjs/`)

| Template | Goes to |
| --- | --- |
| `lib/auth-config.ts` | `lib/auth-config.ts` — edit site name, URLs, copy, social |
| `styles/auth-tokens.css` | `styles/auth-tokens.css` — edit `:root` brand tokens only |
| `app/sign-in/page.tsx` (etc.) | thin pages if missing |
| `app/sso-callback/page.tsx` | required if social is on |
| `middleware.ts` | merge protected matchers |
| `env.template` | merge into `.env.local` — never commit |

Do **not** copy `templates/nextjs/components/auth/*` — those are obsolete;
import from `@braddcorp/auth`.

## 3. Wire layout

```tsx
import "@braddcorp/auth/styles.css"
import "@/styles/auth-tokens.css"
import { AuthKitProvider } from "@braddcorp/auth"
import { authConfig } from "@/lib/auth-config"

<ClerkProvider>
  <AuthKitProvider config={authConfig}>{children}</AuthKitProvider>
</ClerkProvider>
```

`auth-config.ts` must `satisfies AuthConfig` (import type from the package).

## 4. Pages

```tsx
import {
  AuthShell,
  SignInForm,
  safeReturnPath,
} from "@braddcorp/auth"
import { authConfig } from "@/lib/auth-config"

const afterUrl =
  safeReturnPath(redirect_url, authConfig.allowedReturnHosts) ??
  authConfig.afterSignInUrl
```

Site extras (Turnstile, invite cards): wrap forms or pass props
(`beforeEmailContinue`, `emailStepExtra`, `beforeSubmit`, `formExtra`,
`beforeSendCode`, `submitDisabled`).

## 5. Verify

1. Password sign-in → `afterSignInUrl`
2. Wrong password → field error
3. Forgot password → code → new password
4. Passwordless account → email code path (no strategy error)
5. Sign-up → email code → `afterSignUpUrl`
6. Social (if on) both directions
7. Incognito Device Trust email code

## Updating after a kit change

Tag/push in `braddcorp-auth`, then in each site:

```bash
npm install github:BadBraddA1/braddcorp-auth#vX.Y.Z
# or: npm update @braddcorp/auth   # when pinned to #main
```

Commit the lockfile and deploy. Prefer Renovate/Dependabot on the github dep
for hands-off bumps.

## Known traps

- Never `<UserButton>` — use `<AccountMenu />` from the package.
- Custom Clerk domain: CNAMEs DNS-only; `useClerkReady()` surfaces load fails.
- Keep `<div id="clerk-captcha" />` (inside `SignUpForm`).
- `errors.fields.identifier` on sign-in; `emailAddress` on sign-up.
- Hex/oklch literals in `auth-tokens.css` — never `var(--site-token)`.
