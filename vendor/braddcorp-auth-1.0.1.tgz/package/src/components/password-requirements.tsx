"use client"

import { useId, useState } from "react"

/** Matches H&M / BraddCorp Clerk `auth_password.min_length` (keep in sync). */
export const PASSWORD_MIN_LENGTH = 12

export type PasswordRule = {
  id: string
  label: string
  test: (password: string) => boolean
}

export const DEFAULT_PASSWORD_RULES: PasswordRule[] = [
  {
    id: "length",
    label: `At least ${PASSWORD_MIN_LENGTH} characters`,
    test: (p) => p.length >= PASSWORD_MIN_LENGTH,
  },
]

export function passwordMeetsRequirements(
  password: string,
  rules: PasswordRule[] = DEFAULT_PASSWORD_RULES,
): boolean {
  return rules.every((r) => r.test(password))
}

/**
 * Live checklist under new-password fields. Checks update as the user types.
 */
export function PasswordRequirements({
  password,
  rules = DEFAULT_PASSWORD_RULES,
}: {
  password: string
  rules?: PasswordRule[]
}) {
  const listId = useId()
  return (
    <ul
      id={listId}
      className="ba-password-reqs"
      aria-label="Password requirements"
    >
      {rules.map((rule) => {
        const met = rule.test(password)
        return (
          <li
            key={rule.id}
            className={met ? "ba-password-req is-met" : "ba-password-req"}
          >
            <span className="ba-password-req-mark" aria-hidden="true">
              {met ? "✓" : "○"}
            </span>
            <span>{rule.label}</span>
            <span className="ba-sr-only">
              {met ? "met" : "not met yet"}
            </span>
          </li>
        )
      })}
    </ul>
  )
}

/**
 * Drop-in new-password field with live requirements (keeps `name="password"` for form actions).
 */
export function NewPasswordField({
  id = "password",
  label = "Password",
  autoComplete = "new-password",
  invalid = false,
  errorMessage,
  minLength = PASSWORD_MIN_LENGTH,
  rules = DEFAULT_PASSWORD_RULES,
}: {
  id?: string
  label?: string
  autoComplete?: string
  invalid?: boolean
  errorMessage?: string
  minLength?: number
  rules?: PasswordRule[]
}) {
  const [password, setPassword] = useState("")
  const reqId = `${id}-requirements`

  return (
    <div className="ba-field">
      <label htmlFor={id} className="ba-label">
        {label}
      </label>
      <input
        id={id}
        name="password"
        type="password"
        autoComplete={autoComplete}
        required
        minLength={minLength}
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="ba-input"
        aria-invalid={invalid || undefined}
        aria-describedby={reqId}
      />
      <div id={reqId}>
        <PasswordRequirements password={password} rules={rules} />
      </div>
      {errorMessage ? <p className="ba-error">{errorMessage}</p> : null}
    </div>
  )
}
