"use client"

import { createContext, useContext, type ReactNode } from "react"

export type SocialProvider = "oauth_google" | "oauth_apple"

export type AuthConfig = {
  siteName: string
  homeUrl: string
  afterSignInUrl: string
  afterSignUpUrl: string
  signInUrl: string
  signUpUrl: string
  forgotPasswordUrl: string
  ssoCallbackUrl: string
  collectName: boolean
  allowedReturnHosts: string[]
  socialProviders: SocialProvider[]
  copy: {
    signInTitle: string
    signInSubtitle: string
    signUpTitle: string
    signUpSubtitle: string
    forgotTitle: string
    forgotSubtitle: string
  }
}

const AuthConfigContext = createContext<AuthConfig | null>(null)

/** Provide per-site auth settings to kit components. */
export function AuthKitProvider({
  config,
  children,
}: {
  config: AuthConfig
  children: ReactNode
}) {
  return (
    <AuthConfigContext.Provider value={config}>
      {children}
    </AuthConfigContext.Provider>
  )
}

export function useAuthConfig(): AuthConfig {
  const ctx = useContext(AuthConfigContext)
  if (!ctx) {
    throw new Error(
      "@braddcorp/auth: wrap your app with <AuthKitProvider config={authConfig}>.",
    )
  }
  return ctx
}
