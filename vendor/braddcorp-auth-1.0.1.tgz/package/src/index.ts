export type { AuthConfig, SocialProvider } from "./config"
export { AuthKitProvider, useAuthConfig } from "./config"

export {
  afterAuth,
  authErrorHasCode,
  globalAuthError,
  safeReturnPath,
} from "./after-auth"

export { AccountMenu } from "./components/account-menu"
export { AuthPending } from "./components/auth-pending"
export { AuthShell } from "./components/auth-shell"
export { ForgotPasswordForm } from "./components/forgot-password-form"
export {
  DEFAULT_PASSWORD_RULES,
  NewPasswordField,
  PASSWORD_MIN_LENGTH,
  PasswordRequirements,
  passwordMeetsRequirements,
  type PasswordRule,
} from "./components/password-requirements"
export { SignInForm } from "./components/sign-in-form"
export { SignUpForm } from "./components/sign-up-form"
export { SocialButtons } from "./components/social-buttons"
export { CLERK_LOAD_ERROR, useClerkReady } from "./components/use-clerk-ready"
