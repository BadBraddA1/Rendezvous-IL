/**
 * `errors.global` changed shape across @clerk/nextjs v7 minors
 * (array of ClerkError → single ClerkError | null). Normalize to one-or-null.
 */
export function globalAuthError(errors: {
  global: unknown
}): { message: string; longMessage?: string } | null {
  const g = errors.global as
    | { message: string; longMessage?: string }
    | { message: string; longMessage?: string }[]
    | null
    | undefined
  if (!g) return null
  return Array.isArray(g) ? (g[0] ?? null) : g
}

/**
 * Middleware bounces signed-out users to /sign-in?redirect_url=… — honor it
 * so deep links survive login, but only same-site paths or hosts listed in
 * allowedReturnHosts (never an open redirect).
 */
export function safeReturnPath(
  raw: string | string[] | undefined,
  allowedReturnHosts: string[] = [],
): string | null {
  const value = Array.isArray(raw) ? raw[0] : raw
  if (!value) return null
  if (value.startsWith("/") && !value.startsWith("//")) return value
  try {
    const url = new URL(value)
    if (
      url.protocol === "https:" &&
      allowedReturnHosts.includes(url.host)
    ) {
      return url.origin + url.pathname + url.search
    }
  } catch {
    /* not a URL */
  }
  return null
}

/**
 * True when a Clerk error (single error or API response with an errors
 * array) carries the given machine-stable code, e.g.
 * "form_identifier_not_found" for an unknown sign-in email.
 */
export function authErrorHasCode(error: unknown, code: string): boolean {
  if (!error || typeof error !== "object") return false
  if ((error as { code?: string }).code === code) return true
  const nested = (error as { errors?: { code?: string }[] }).errors
  return Array.isArray(nested) && nested.some((e) => e?.code === code)
}

/**
 * Shared `finalize({ navigate })` handler for Clerk Core 3 flows.
 * Always a FULL navigation, never router.push().
 */
export function afterAuth(destination: string) {
  return async ({
    session,
    decorateUrl,
  }: {
    session: { currentTask?: unknown } | null | undefined
    decorateUrl: (url: string) => string
  }) => {
    if (session?.currentTask) return
    window.location.assign(decorateUrl(destination))
  }
}
